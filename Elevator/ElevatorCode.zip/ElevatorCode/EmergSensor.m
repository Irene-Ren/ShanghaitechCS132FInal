classdef EmergSensor < handle
    
    properties
        s_emerg1=0;     %status of elevator1's emergency:0..40
        s_emerg2=0;     %status of elevator2's emergency:0..40
    end
      
end
classdef DoorSensor < handle
    
    properties
        s_door1=0;      %status of door1:0..30
        s_door2=0;      %status of door2:0..30
    end
      
end
classdef Nurse < People
    properties
        ID = '9999'     %default
        password ='9999'    %default
        nUIapp   %nurseUI
        pump     %pump response to the nurseUI  
        PWUI     %passwordUI
    end
    
    methods
    end
    
end
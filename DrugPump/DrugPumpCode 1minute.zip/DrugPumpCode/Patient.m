classdef Patient < People
    properties
        patientID
        button
        pump
        Amountofhour
        Amountofday
    end
        
    methods
    end    
end
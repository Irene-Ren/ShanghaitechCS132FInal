classdef People < handle
    properties
        name
    end
    
    methods
    end
    
end
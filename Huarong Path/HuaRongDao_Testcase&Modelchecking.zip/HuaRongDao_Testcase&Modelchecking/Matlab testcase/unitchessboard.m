classdef unitchessboard < matlab.unittest.TestCase
    methods (Test)
        function testdownCheck1(testCase) % T1.1.1.1
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirD = CD.downCheck(CD.Cao_row,CD.Cao_col);
            % Check expected output
            testCase.verifyEqual(is_dirD,false);
        end
        function testdownCheck2(testCase) % T11..1.2
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirD = CD.downCheck(CD.Soldier_1_row,CD.Soldier_1_col);
            % Check expected output
            testCase.verifyEqual(is_dirD,true);
        end
        
        function testupCheck1(testCase) % T1.1.2.1
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,0,1,1;1,1,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=5;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirU = CD.upCheck(CD.Cao_row,CD.Cao_col);
            % Check expected output
            testCase.verifyEqual(is_dirU,false);
        end
        
        function testupCheck2(testCase) % T1.1.2.2
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,0,1,1;1,1,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=5;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirU = CD.upCheck(CD.Soldier_1_row,CD.Soldier_1_col);
            % Check expected output
            testCase.verifyEqual(is_dirU,true);
        end
        
        function testrightCheck1(testCase) % T1.1.3.1
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirR = CD.rightCheck(CD.Soldier_3_row,CD.Soldier_3_col);
            % Check expected output
            testCase.verifyEqual(is_dirR,true);
        end
        
        
        function testrightCheck2(testCase) % T1.1.3.2
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirR = CD.rightCheck(CD.Soldier_4_row,CD.Soldier_4_col);
            % Check expected output
            testCase.verifyEqual(is_dirR,false);
        end
        
        function testleftCheck1(testCase) % T1.1.4.1
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,0,1;1,0,1,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=5;
            CD.Soldier_3_row=5;
            Cd.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirL = CD.leftCheck(CD.Cao_row,CD.Cao_col);
            % Check expected output
            testCase.verifyEqual(is_dirL,false);
        end
        
        function testleftCheck2(testCase) % T1.1.4.2
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,0,1;1,0,1,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=5;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            is_dirL = CD.leftCheck(CD.Soldier_2_row,CD.Soldier_2_col);
            % Check expected output
            testCase.verifyEqual(is_dirL,true);
        end
        
        function testdownMove(testCase) % T1.1.5
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            CD.downMove(CD.Soldier_1_row,CD.Soldier_1_col);
            % Check expected output
            testCase.verifyEqual(CD.matrix,[1,1,1,1;1,1,1,1;1,1,1,1;1,0,1,1;1,1,0,1]);
        end
        
        function testupMove(testCase) % T1.1.6
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,0,1,1;1,1,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=5;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            CD.upMove(CD.Soldier_1_row,CD.Soldier_1_col);
            % Check expected output
            testCase.verifyEqual(CD.matrix,[1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1]);
        end
        
        function testleftMove(testCase) % T1.1.7
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,0,1;1,0,1,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=5;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            CD.leftMove(CD.Soldier_2_row,CD.Soldier_2_col);
            % Check expected output
            testCase.verifyEqual(CD.matrix,[1,1,1,1;1,1,1,1;1,1,1,1;1,1,0,1;1,1,0,1]);
        end
        
        function testrightMove(testCase) % T1.1.8
            CD = ChessBoard;
            CD.matrix = [1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1];
            CD.Cao_row=[1,2];
            CD.ZhangFei_row=[1,2];
            CD.ZhaoYun_row=[1,2];
            CD.HuangZhong_row=[3,4];
            CD.MaChao_row=[3,4];
            CD.GuanYu_row=3;
            CD.Soldier_1_row=4;
            CD.Soldier_2_row=4;
            CD.Soldier_3_row=5;
            CD.Soldier_4_row = 5;
            CD.Cao_col=[2,3];
            CD.ZhangFei_col=1;
            CD.ZhaoYun_col=4;
            CD.HuangZhong_col=1;
            CD.MaChao_col=4;
            CD.GuanYu_col=[2,3];
            CD.Soldier_1_col=2;
            CD.Soldier_2_col=3;
            CD.Soldier_3_col=1;
            CD.Soldier_4_col=4;
            % Execute the function
            CD.rightMove(CD.Soldier_3_row,CD.Soldier_3_col);
            % Check expected output
            testCase.verifyEqual(CD.matrix,[1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;0,1,0,1]);
        end
        
        function test(testCase) % T1.1.9
            CD = ChessBoard;
            CD.InitAttributes([1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1],[1,2],[2,3],[1,2],1,[1,2],4,[3,4],1,[3,4],4, ...
                3,[2,3],4,2,4,3,5,1,5,4);
            testCase.verifyEqual(CD.matrix,[1,1,1,1;1,1,1,1;1,1,1,1;1,1,1,1;1,0,0,1]);
            testCase.verifyEqual(CD.Cao_row,[1,2]);
            testCase.verifyEqual(CD.ZhangFei_row,[1,2]);
            testCase.verifyEqual(CD.ZhaoYun_row,[1,2]);
            testCase.verifyEqual(CD.HuangZhong_row,[3,4]);
            testCase.verifyEqual(CD.MaChao_row,[3,4]);
            testCase.verifyEqual(CD.GuanYu_row,3);
            testCase.verifyEqual(CD.Soldier_1_row,4);
            testCase.verifyEqual(CD.Soldier_2_row,4);
            testCase.verifyEqual(CD.Soldier_3_row,5);
            testCase.verifyEqual(CD.Soldier_4_row,5);
            testCase.verifyEqual(CD.Cao_col,[2,3]);
            testCase.verifyEqual(CD.ZhangFei_col,1);
            testCase.verifyEqual(CD.ZhaoYun_col,4);
            testCase.verifyEqual(CD.HuangZhong_col,1);
            testCase.verifyEqual(CD.MaChao_col,4);
            testCase.verifyEqual(CD.GuanYu_col,[2,3]);
            testCase.verifyEqual(CD.Soldier_1_col,2);
            testCase.verifyEqual(CD.Soldier_2_col,3);
            testCase.verifyEqual(CD.Soldier_3_col,1);
            testCase.verifyEqual(CD.Soldier_4_col,4);
        end
    end 
end
close all
clear all

infos = ChessBoard;
mainMenuUI = mainMenu(infos);

mainMenuUI.m_chessboard = infos;